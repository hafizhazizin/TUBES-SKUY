<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width-divice-width, initial-scale-1">
    <link rel="stylesheet" href="..\asset\css\bootstrap.min.css"/>
</head>
<body>
    <form action="view.php" method="Post">
        <table>
            <div class="container">
                <div class="row w-50 m-auto">
                    <div class="col pt-3">
                        <h1 class="text-center">SEWA</h1>
                    <div class="form-group">
                        <label for="fornkendaraan">Nama Kendaraan</label>
                        <input type="text" class="form-control" id="fornkendaraan" placeholder="Nama Kendaraan" name="kendaraan">
                    </div>
                    <div class="form-group">
                        <label for="forSewap">Sewa Perhari</label>
                        <input type="text" class="form-control" id="forsewap" placeholder="Sewa Perhari" name="sewap">
                    </div>
                    <div class="form-group">
                        <label for="fortglsewa">Tanggal Sewa</label>
                        <input type="date" class="form-control" id="fortglsewa" placeholder="Tanggal Sewa" name="tglsewa">
                    </div>
                    <div class="input-group mb-3">
                      <div class="input-group-prepend">
                        <label class="input-group-text" for="inputdurasisewa">Durasi Sewa</label>
                      </div>
                      <select class="custom-select" id="inputdurasisewa" name="durasisewa">
                        <option selected>Choose...</option>
                        <option value="1Hari">1 Hari</option>
                        <option value="3Hari">3 Hari</option>
                        <option value="5Hari">5 Hari</option>
                        <option value="7Hari">7 Hari</option>
                      </select>
                    </div>
                    <div class="form-group text-center">   
                    <input type="submit" class="btn btn-primary" name="submit" value="Submit"> <a href="dashboard.php" class="btn btn-success mr-2">Dashboard</a>
                </div>
                    </div>
                </div>
            </div>
        </table>
    </form>
</body>
</html>