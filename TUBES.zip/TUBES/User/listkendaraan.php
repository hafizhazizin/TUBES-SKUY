<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action=""  method="Post" >
        <table>
            <h1>List Kendaraan</h1>
            <tr>
                <td align="center">Avanza</td>
                <td align="center">Matic</td>
            </tr>
            <tr>
                <td align="center"><a href="sewa.php"><img src="../gambar/avanza-silver-metallic.jpg" alt="" width="30%"></a></td>
                <td align="center"><a href="sewa.php"><img src="../gambar/Honda-Vario-125-eSP.jpg" alt="" width="50%"></a></td>
            </tr>
            <tr>
            <td><a href="dashboard.php">Kembali Ke Dashboard</a></td>
            </tr>
        </table>
    </form>
</body>
</html>