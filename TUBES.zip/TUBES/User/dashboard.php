<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action=""method="Post">
        <table>
            <tr>
                <td><a href="Profile.php">Profile</a></td>
                <td><a href="listkendaraan.php">List Kendaraan</a></td>
                <td><a href="sewa.php">Sewa</a></td>
                <td><a href="..\index.php">Logout</a></td>
            </tr>
        </table>
    </form>
</body>
</html>