<?php
    class data{
        private $conn;

        public function __construct(){
            $server ="localhost";
            $user ="root";
            $pass ="";
            $db ="skuy";
            $this->conn=mysqli_connect($server,$user,$pass,$db);
        }
    
        public function edit_profile($nik,$nama,$alamat,$hp,$email,$foto){
            $sql = mysqli_query($this->conn, "SELECT * FROM login WHERE id_user = '$id'");
            $row = mysqli_fetch_assoc($sql);

            $sql = $sql = "UPDATE data_user SET nik ='$nik',nama ='$nama',alamat ='$alamat', no_hp='$hp',foto='$foto'";
            if ( mysqli_query($this->conn,$sql)) {
                ?>
                <script>
                    alert("Data Berhasil Diubah");
                    location="Profile.php";
                </script>
                <?php
            }else{
                ?>
                <script>
                    alert("Data gagal Diubah");
                    location="Profile.php";
                </script>
                <?php
            }      
        }
        public function tampil_data($nik){
            $sql = mysqli_query($this->conn, "SELECT * FROM data_user WHERE nik = '$nik'");
            return $sql;
        }
    }
    $data = new data();
    if(isset($_GET['edit_profile'])){
    $proses->edit_profile($_GET['edit'],$_POST['nama'],$_POST['alamat'],$_POST['no_hp'],$_POST['foto'],$_POST['email']);        
    }
?>   